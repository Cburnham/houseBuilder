package solvd.builder;


import solvd.house.House;


public interface IBuilder {

    House getResult();

}
