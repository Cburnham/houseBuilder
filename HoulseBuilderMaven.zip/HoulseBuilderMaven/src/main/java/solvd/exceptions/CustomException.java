package solvd.exceptions;

public class CustomException extends Exception{
    public CustomException(String str){
        super(str);
    }
}
