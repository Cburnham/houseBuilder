package solvd.person;

public interface IPerson {

    public String getFirstName();

    public void setFirstName(String firstName);

    public String getLastName();

    public void setLastName(String lastName);

    public String getPhoneNumber();

    public void setPhoneNumber(String phoneNumber);
}
