package com.solvd.builder;

import com.solvd.company.Company;
import com.solvd.materials.Door;
import com.solvd.materials.Roof;
import com.solvd.materials.Walls;
import com.solvd.materials.Windows;
import com.solvd.person.Customer;

public interface IBuilder {


    void setWalls(Walls walls);
        void setRoof(Roof roof);
        void setWindows(Windows windows);
        void setDoor(Door door);
        void setGarage(boolean garage);
        void setPoll(boolean pool);
        void setCountFlor(int countFlor);
        void setCustomer(Customer customer);
        void setCompany(Company company);

}
