package com.solvd.materials;

public enum Material {
    BRICK,PANEL,STONE,WOOD,BLOCK,TILING,METAL,SLATE,PLASTIC
}