package com.solvd.person;

public class Customer extends Person{
    public Customer(String firstName, String lastName, String phoneNumber) {
        super(firstName, lastName, phoneNumber);
    }


}
