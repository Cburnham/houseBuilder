package com.solvd;

import com.solvd.builder.Build;
import com.solvd.builder.HouseBuilder;
import com.solvd.builder.IBuilder;
import com.solvd.house.House;

public class Main {

    public static void main(String[] args) {
        Build buildOne = new Build();
        HouseBuilder builder = new HouseBuilder();

        buildOne.constructFirstHouse((IBuilder) builder);
        House house1 = builder.getResult();
        System.out.println(house1.getInfo());

        buildOne.constructSecondHouse((IBuilder) builder);
        House house2 = builder.getResult();
        System.out.println(house2.getInfo());
    }
}
