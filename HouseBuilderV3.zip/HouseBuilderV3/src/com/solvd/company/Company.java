package com.solvd.company;

import com.solvd.person.Employee;
import com.solvd.person.Person;

import java.util.List;

public abstract class Company implements ICompany {
    private String companyName;
    private String address;
    private String phoneNumber;
    private List<Employee> employees;

    public Company(String companyName, String address, String phoneNumber) {
        this.companyName = companyName;
        this.address = address;
        this.phoneNumber = phoneNumber;

    }

}
