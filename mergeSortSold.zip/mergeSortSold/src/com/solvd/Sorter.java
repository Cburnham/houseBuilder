package com.solvd;

public class Sorter {

    /*
    recursive function for merge sort
    insert an array, the left index, the right index, and the middle index

     */
    public void merge(int[] arr, int left, int middle, int right)
    {
        //find the sizes of the sub arrays
        int subOne = middle-left + 1;
        int subTwo = right-middle;

        int tempLeft[] = new int[subOne];
        int tempRight[] = new int[subTwo];
        //copy arrays into temps
        for (int i = 0; i < subOne; ++i){
            tempLeft[i] = arr[left + i];
        }

        // compare values and reassign
        for (int j = 0; j < subTwo; ++j){
            tempRight[j] = arr[middle+1+j];
        }
        // begin merging
        int i = 0;
        int j = 0;
        int k = left;
        while (i  < subOne && j < subTwo){
            if (tempLeft[i] <= tempRight[j]){
//                int tempTempTemp =
                arr[k] = tempLeft[i];
                i++;
            } else{
                arr[k] = tempRight[j];
                j++;
            }
            k++;
        }
        while (i < subOne){
            arr[k] = tempLeft[i];
            i++;
            k++;
        }
        while ( j < subTwo){
            arr[k] = tempRight[j];
            j++;
            k++;
        }
       // return arr;
      //  return arr;
    }
    /*
    Recursive function to sort
    input an array, a left index and a right index
     */
    public void mergeSort(int[] arr, int left, int right){
        if (left < right){
            //find middle
            int middle = left + (right - left)/2;
            //sort left side
            mergeSort(arr, left, middle);
            //sort right side
            mergeSort(arr, middle+1, right);
            //merge
            merge(arr, left, middle, right);
        }

    }
    public static void print(int arr[]){
        int z = arr.length;

        System.out.print("[ ");
        for(int i = 0; i < z; ++i){
            System.out.print(arr[i] + " ");
        }
        System.out.println(" ]");
    }

}