package com.solvd;

public class Main {

    public static void main(String[] args) {
       // int arr[] = { 33,22,424,56,76,54,3,7,12,3,4,2,1,111,01 };
        int arr[] = {9,8,7,0,6,4,5,0,1,0,2,3};
        Sorter mergeSorter = new Sorter();
        System.out.println("new Sorter created, using merge sort on" );
        mergeSorter.print(arr);
        System.out.println("Beep boop");


        mergeSorter.mergeSort(arr, 0, arr.length - 1);

        System.out.println("\nMerged and sorted");
        mergeSorter.print(arr);
    }
}
